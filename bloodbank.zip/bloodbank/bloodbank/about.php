<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="styles.css"> <!-- Optional CSS file -->
    <style>
        /* Inline styles for demonstration purposes; ideally move to styles.css */
        .text-center { text-align: center; }
        .team-member img {
            width: 200px; /* Fixed width */
            height: 200px; /* Fixed height */
            object-fit: cover; /* Maintain aspect ratio and cover the area */
        }
    </style>
</head>
<body>
    <header>
        <h1>About Us</h1>
    </header>
    
    <main>
        <section>
            <h1>Welcome to Bloodbank Management System</h1>
            <p>A Blood Bank Management System in PHP will efficiently manage blood donations and inventory...</p>
        </section>
        
        <section>
            <div class="text-center">
                <h2>Guided by</h2>
                <img src="assets/uploads/teacher.png" alt="Prof. ParthaSarathy P.V" class="img-responsive img-thumbnail">
                <h4>Prof. ParthaSarathy P.V</h4>
                <p>Professor Parthasarathy PV has been a guiding force in the development of our Bloodbank management system project...</p>
            </div>
        </section>

        <section>
            <div class="text-center">
                <h2>Our Team</h2>
                <div class="row fadeInDown animated" data-wow-delay="0.5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
                    <div class="col-md-3 text-center team-member">
                        <img src="assets/uploads/team1.jpg" alt="S Kusuma" class="img-responsive img-thumbnail">
                        <h4>S Kusuma</h4>
                        <p>Web Developer</p>
                        <p>I am a positive, enthusiastic, and competent Web Developer...</p>
                    </div>
                    <div class="col-md-3 text-center team-member">
                        <img src="assets/uploads/team2.jpg" alt="Sheershika GV" class="img-responsive img-thumbnail">
                        <h4>Sheershika GV</h4>
                        <p>Web Developer</p>
                        <p>I have extensive experience working both alone and as part of a team...</p>
                    </div>
                    <div class="col-md-3 text-center team-member">
                        <img src="assets/uploads/team3.jpg" alt="Prabha Anand Harapale" class="img-responsive img-thumbnail">
                        <h4>Prabha Anand Harapale</h4>
                        <p>Android Developer</p>
                        <p>Highly motivated and detail-oriented web developer...</p>
                    </div>
                    <div class="col-md-3 text-center team-member">
                        <img src="assets/uploads/team4.jpg" alt="Sangeetha D" class="img-responsive img-thumbnail">
                        <h4>Sangeetha D</h4>
                        <p>Android Developer</p>
                        <p>I am an experienced Android Developer with a passion for developing innovative mobile applications...</p>
                    </div>
                </div>
            </div>
        </section>

        <section id="packages" class="secPad">
            <div class="container">
                <div class="heading text-center">
                    <!-- Content for packages section can be added here -->
                </div>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> AMC Engineering College</p>
    </footer>
</body>
</html>
